<?php
session_start();
include_once 'session/CustomSessionHandler.php';

// Get products from the session cart
$cart = CustomSessionHandler::getProductsInCart();

// Function to handle increasing quantity
function increaseQuantity($productID) {
    if(isset($_SESSION['cart'][$productID])) {
        $_SESSION['cart'][$productID]['quantity']++;
    }
}

// Function to handle decreasing quantity
function decreaseQuantity($productID) {
    if(isset($_SESSION['cart'][$productID])) {
        $_SESSION['cart'][$productID]['quantity']--;
        if($_SESSION['cart'][$productID]['quantity'] <= 0) {
            unset($_SESSION['cart'][$productID]);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>

<body>
    <?php include('header.php'); ?>

    <div class="container mt-5">
        <h2 class="text-center">Cart Details</h2>

        <?php if (empty($cart)) : ?>
            <div class="text-center">
                <p>Your cart is empty.</p>
                <a href="index.php" class="btn btn-primary">Go to Home Page</a>
            </div>
        <?php else : ?>
            <br />
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">Product Name</th>
                                        <th scope="col">Quantity</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($cart as $productID => $productData) : ?>
                                        <tr>
                                            <td><?= $productData['name'] ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-secondary" onclick="decreaseQuantity(<?= $productID ?>)">-</button>
                                                <span><?= $productData['quantity'] ?></span>
                                                <button class="btn btn-sm btn-secondary" onclick="increaseQuantity(<?= $productID ?>)">+</button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-center">
                <a href="checkout.php" class="btn btn-primary <?php echo empty($cart) ? 'disabled' : ''; ?>" <?php echo empty($cart) ? 'disabled' : ''; ?>>Proceed to Checkout</a>
            </div>
        <?php endif; ?>
    </div>

    <script>
        // JavaScript functions to handle quantity changes
        function increaseQuantity(productID) {
            window.location.href = 'increase_quantity.php?id=' + productID;
        }

        function decreaseQuantity(productID) {
            window.location.href = 'decrease_quantity.php?id=' + productID;
        }
    </script>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</body>

</html>
