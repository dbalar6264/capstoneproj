<?php
include_once 'DatabaseInitializer.php';
include_once './models/product.php';

class ProductsDatabse extends DatabaseInitializer
{

    public function __construct()
    {
        parent::__construct();
        $this->connect();
    }

    public function getCategories()
    {
        $sqlCategories = "SELECT Category_ID, Category_Name FROM Category";
        $resultCategories = $this->db->query($sqlCategories);

        $categories = [];
        while ($rowCategory = $resultCategories->fetch_assoc()) {
            $categories[] = $rowCategory;
        }

        return $categories;
    }

    public function getProducts($categoryID = null)
    {
        $sql = "SELECT * FROM Products";


        // Getting CategoryID from the URL queryparam and checking for its pattern
        if ($categoryID !== null && preg_match("/^[0-9]+$/", $categoryID) && $categoryID != 'all') {
            $sql .= " WHERE Category_ID = ?";
        }

        // Create a prepared statement and bind parameters
        $stmt = mysqli_prepare($this->db, $sql);
        if ($categoryID !== null && $categoryID != 'all') {
            mysqli_stmt_bind_param($stmt, "i", $categoryID);
        }

        $result = mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        $products = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $products[] = new Product(
                $row['Product_ID'],
                $row['Product_Name'],
                $row['Product_Brand'],
                $row['Quantity_Available'],
                $row['Price'],
                $row['Product_Description'],
                $row['Category_ID'],
                $row['ImageUrl'] ?? ''
            );
        }

        return $products;
    }

    public function getProductDetails($productID)
    {
        $sql = "SELECT * FROM Products WHERE Product_ID = ?";

        $stmt = mysqli_prepare($this->db, $sql);
        mysqli_stmt_bind_param($stmt, "i", $productID);

        $result = mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        $product = null;
        if ($row = mysqli_fetch_assoc($result)) {
            $product = new Product(
                $row['Product_ID'],
                $row['Product_Name'],
                $row['Product_Brand'],
                $row['Quantity_Available'],
                $row['Price'],
                $row['Product_Description'],
                $row['Category_ID'],
                $row['ImageUrl'] ?? ''
            );
        }

        return $product;
    }

    //Save Order details into Order table and after that save OrderItems based on returned OrderId
    public function saveOrderDetails($userID, $address)
    {
        $sql = "INSERT INTO Orders (User_ID, Shipping_Address) VALUES (?, ?)";
        $stmt = mysqli_prepare($this->db, $sql);
        mysqli_stmt_bind_param($stmt, "ss", $userID, $address);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        return mysqli_insert_id($this->db);
    }

    // Save individual items of an Order in the Databse...
    public function saveOrderItem($orderID, $productID, $quantity)
    {
        $sql = "INSERT INTO OrderItems (Order_ID, Product_ID, Quantity) VALUES (?, ?, ?)";
        $stmt = mysqli_prepare($this->db, $sql);
        mysqli_stmt_bind_param($stmt, "iii", $orderID, $productID, $quantity);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }

    // Get details of a specific order based on Order_ID
    public function getOrderDetails($orderID)
    {
        $orderID = intval($orderID);
        $sql = "SELECT * FROM Orders WHERE Order_ID = ?";
        $stmt = mysqli_prepare($this->db, $sql);
        mysqli_stmt_bind_param($stmt, "i", $orderID);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $order = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $order[] = $row;
        }
        mysqli_stmt_close($stmt);

        return $order[0];
    }

    // Get all OrderItems based on Order_ID
    public function getOrderItems($orderID)
    {
        $sql = "SELECT * FROM OrderItems WHERE Order_ID = ?";
        $stmt = mysqli_prepare($this->db, $sql);
        mysqli_stmt_bind_param($stmt, "i", $orderID);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        $orderItems = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $orderItems[] = $row;
        }

        mysqli_stmt_close($stmt);

        return $orderItems;
    }

    // Method to Delte the Product based on ProductId
    public function deleteProduct($productID)
    {
        $sql = "DELETE FROM Products WHERE Product_ID = ?";
        $stmt = mysqli_prepare($this->db, $sql);
        mysqli_stmt_bind_param($stmt, "i", $productID);
        $success = mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        return $success;
    }

    // Getting the Product Details Based on ID
    public function getProductById($productId)
    {
        $sql = "SELECT * FROM Products WHERE Product_ID = ?";
        $stmt = mysqli_prepare($this->db, $sql);
        mysqli_stmt_bind_param($stmt, "i", $productId);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $productDetails = mysqli_fetch_assoc($result);
        mysqli_stmt_close($stmt);

        return $productDetails;
    }

    // Udating the prodict details based in productId using where cluse..
    public function updateProduct($productId, $productName, $productDescription, $categoryID, $price, $brand, $quantity, $imageUrl)
    {
        $sql = "UPDATE Products SET Product_Name = ?, Product_Description = ?, Category_ID = ?, Price = ?, Product_Brand = ?, Quantity_Available = ?, ImageUrl = ?  WHERE Product_ID = ?";
        $stmt = mysqli_prepare($this->db, $sql);
        mysqli_stmt_bind_param($stmt, "ssidsisi", $productName, $productDescription, $categoryID, $price, $brand, $quantity, $imageUrl ,$productId);
        $success = mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        return $success;
    }

    //Creates a new Product in the Database...
    public function createProduct($productName, $productDescription, $quantityAvailable, $price, $brand, $categoryID, $imageUrl)
    {
        $sql = "INSERT INTO Products (Product_Name, Product_Description, Quantity_Available, Price, Product_Brand, Category_ID, ImageUrl) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($this->db, $sql);
        mysqli_stmt_bind_param($stmt, "ssidsis", $productName, $productDescription, $quantityAvailable, $price, $brand, $categoryID, $imageUrl);
        $success = mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        return $success;
    }
}
