<?php
class DatabaseInitializer
{
    private $server;
    private $user;
    private $password;
    private $schema;
    public $db;

    public function __construct()
    {
        //Cloud databse hosting
        // $this->server = "sql5.freesqldatabase.com";
        // $this->user = "sql5669300";
        // $this->password = "W8NESq76PV";
        // $this->schema = "sql5669300";

        //Local Database
        $this->server = "localhost";
        $this->user = "root";
        $this->password = "";
        $this->schema = "phpfinal";
    }

    /**
     * Create Schema
     * Create Tables
     * Create Dummy Data.
     */

    public function initDatabase()
    {

        $this->db = new mysqli($this->server, $this->user, $this->password);
        $this->createSchema();
        $this->createTables();
        $this->insertDummyCategories();

        $this->db->close();
    }

    public function getConnectionObject()
    {
        return $this->db;
    }

    public function connect()
    {
        $this->db = new mysqli($this->server, $this->user, $this->password, $this->schema);

        if ($this->db->connect_error) {
            die("Failed to connect to Database: " . $this->db->connect_error);
        }
        return $this->db;
    }

    private function createSchema()
    {
        $createSchemaQuery = "CREATE DATABASE IF NOT EXISTS {$this->schema}";

        if ($this->db->query($createSchemaQuery) === TRUE) {
            echo "Schema created successfully.<br>";
        } else {
            echo "Error creating schema: " . $this->db->error . "<br>";
        }

        $this->db->select_db($this->schema);
    }

    private function createTables()
    {
        $this->connect();
        $createCategoryTable = "CREATE TABLE IF NOT EXISTS Category (
            Category_ID INT AUTO_INCREMENT PRIMARY KEY,
            Category_Name VARCHAR(40) NOT NULL
        )";

        $createTable = "CREATE TABLE IF NOT EXISTS Products (
            Product_ID INT AUTO_INCREMENT PRIMARY KEY,
            Category_ID INT,
            Product_Name VARCHAR(40) NOT NULL,
            Product_Description VARCHAR(100) NOT NULL,
            Product_Brand VARCHAR(20) NOT NULL,
            Quantity_Available INT NOT NULL,
            Price VARCHAR(10),
            ImageUrl VARCHAR(500),
            FOREIGN KEY (Category_ID) REFERENCES Category(Category_ID)
        )";

        $createUsersTable = "CREATE TABLE IF NOT EXISTS Users (
            User_ID INT AUTO_INCREMENT PRIMARY KEY,
            User_Name VARCHAR(40) NOT NULL,
            User_Password VARCHAR(500) NOT NULL,
            User_Email VARCHAR(40) NOT NULL
        )";

        $createOrders = "CREATE TABLE IF NOT EXISTS Orders (
            Order_ID INT AUTO_INCREMENT PRIMARY KEY,
            User_ID INT NOT NULL,
            Shipping_Address VARCHAR(40) NOT NULL,
            Order_Date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (User_ID) REFERENCES Users(User_ID)
        )";

        $createOrderItems = "CREATE TABLE IF NOT EXISTS OrderItems (
            OrderItem_ID INT AUTO_INCREMENT PRIMARY KEY,
            Order_ID INT NOT NULL,
            Product_ID INT NOT NULL,
            Quantity INT NOT NULL,
            FOREIGN KEY (Order_ID) REFERENCES Orders(Order_ID),
            FOREIGN KEY (Product_ID) REFERENCES Products(Product_ID)
        )";

        $this->executeQuery($createCategoryTable, "Category");
        $this->executeQuery($createTable, "Products");
        $this->executeQuery($createUsersTable, "Users");
        $this->executeQuery($createOrders, "Orders");
        $this->executeQuery($createOrderItems, "OrderItems");
    }

    private function insertDummyCategories()
    {
        $insertCategories = "
            INSERT INTO Category (Category_Name) VALUES
            ('Running Shoes'),
            ('Formal Shoes'),
            ('Casual Shoes')
        ";

        $this->executeQuery($insertCategories, "Category");
    }

    private function executeQuery($query, $tableName)
    {
        if ($this->db->query($query) === TRUE) {
            echo "{$tableName} table created successfully.<br>";
        } else {
            echo "Error creating {$tableName} table: " . $this->db->error . "<br>";
        }
    }
}
