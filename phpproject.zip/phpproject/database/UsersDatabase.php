<?php
include_once 'DatabaseInitializer.php';

class UsersDatabase extends DatabaseInitializer
{
    public function __construct()
    {
        parent::__construct();
        $this->connect();
    }


    public function getUserDetails($userID)
    {
        $sql = "SELECT * FROM Users WHERE User_ID = ?";

        $stmt = mysqli_prepare($this->db, $sql);
        mysqli_stmt_bind_param($stmt, "i", $userID);

        $result = mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        $userDetails = mysqli_fetch_assoc($result);

        return $userDetails;
    }

    public function insertUser($username, $password, $email)
    {
        // Check if the user already exists either name or email should match 
        $checkUserQuery = "SELECT * FROM Users WHERE User_Name = ? OR User_Email = ?";
        $checkUserStmt = mysqli_prepare($this->db, $checkUserQuery);
        mysqli_stmt_bind_param($checkUserStmt, "ss", $username, $email);
        mysqli_stmt_execute($checkUserStmt);
        $existingUserResult = mysqli_stmt_get_result($checkUserStmt);

        if ($existingUserResult->num_rows > 0) {
            return false; // User already exists
        }

        // Insert the new user
        $insertUserQuery = "INSERT INTO Users (User_Name, User_Password, User_Email) VALUES (?, ?, ?)";
        $insertUserStmt = mysqli_prepare($this->db, $insertUserQuery);
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        mysqli_stmt_bind_param($insertUserStmt, "sss", $username, $hashedPassword, $email);

        $success = mysqli_stmt_execute($insertUserStmt);

        if ($success) {
            $userID = mysqli_insert_id($this->db);
            return $userID;
        } else {
            return null;
        }
    }

    public function loginUser($username, $password)
    {
        // Check if the user exists
        $checkUserQuery = "SELECT * FROM Users WHERE User_Name = ?";
        $checkUserStmt = mysqli_prepare($this->db, $checkUserQuery);
        mysqli_stmt_bind_param($checkUserStmt, "s", $username);
        mysqli_stmt_execute($checkUserStmt);
        $existingUserResult = mysqli_stmt_get_result($checkUserStmt);

        if ($existingUserResult->num_rows === 0) {
            return null;
        }

        $userDetails = mysqli_fetch_assoc($existingUserResult);

        // Verify the password
        if (password_verify($password, $userDetails['User_Password'])) {
            return $userDetails; // Login successful
        } else {
            return null; // Incorrect password
        }
    }
}
