<?php

class Product
{
    public $productID;
    public $productName;
    public $productBrand;
    public $quantityAvailable;
    public $price;
    public $productDEscription;
    public $categoryID;

    public function __construct($productID, $productName, $productBrand, $quantityAvailable, 
    $price, $productDEscription, $categoryID)
    {
        $this->productID = $productID;
        $this->productName = $productName;
        $this->productBrand = $productBrand;
        $this->quantityAvailable = $quantityAvailable;
        $this->price = $price;
        $this->productDEscription = $productDEscription;
        $this->categoryID = $categoryID;
    }
}
