<?php
session_start();

include_once './session/CustomSessionHandler.php';
include_once './database/ProductsDatabse.php';

// Check if user details are available in the session if not redirect to Registration page...
$userDetails = CustomSessionHandler::getUserDetails();
if (!$userDetails) {
    header('Location: registration.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = htmlspecialchars(trim($_POST["name"]));
    $email = filter_var($_POST["email"], FILTER_VALIDATE_EMAIL);
    $address = htmlspecialchars(trim($_POST["address"]));
    $credit_card = preg_replace("/\D/", "", $_POST["credit_card"]);

    $userID = $userDetails['userId'];

    // Get Products from the cart and store each row in the database
    $databaseHandler = new ProductsDatabse();
    $orderID = $databaseHandler->saveOrderDetails($userID, $address);

    // After saving Order and getting OrderID, save individual Items in orderItems table
    $cartProducts = CustomSessionHandler::getProductsInCart();
    foreach ($cartProducts as $productID => $cartProduct) {
        $quantity = $cartProduct['quantity'];
        $databaseHandler->saveOrderItem($orderID, $productID, $quantity);
    }

    // Clear the cart after placing the order
    CustomSessionHandler::clearCart();

    // Redirect to success.php with the Order ID as a query parameter
    header("Location: success.php?orderID=$orderID");
    exit();
} else {
    header('Location: index.php');
    exit();
}
