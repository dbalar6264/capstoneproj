<?php
include_once './session/CustomSessionHandler.php';

// Check if user details are available in the session
$userDetails = CustomSessionHandler::getUserDetails();
if (!$userDetails) {
    header('Location: registration.php');
    exit();
}
