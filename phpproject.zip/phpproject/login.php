<?php
session_start();

include_once './session/CustomSessionHandler.php';
include_once './database/UsersDatabase.php';

$user = CustomSessionHandler::getUserDetails();
if ($user) {
    header('Location: index.php');
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Handle form submission and login process
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    $errors = [];

    if (empty($username) || !preg_match("/^[a-zA-Z]+$/", $username)) {
        $errors[] = 'Username should contain only alphabets.';
    }

    if (empty($password)) {
        $errors[] = 'All fields are required.';
    }

    if (empty($errors)) {

        $usersDB = new UsersDatabase();

        $loginResult = $usersDB->loginUser($username, $password);

        if ($loginResult) {
            CustomSessionHandler::saveUserDetails($loginResult['User_ID'], $loginResult['User_Name'], $loginResult['User_Email']);

            $cart = CustomSessionHandler::getProductsInCart();

            if (!empty($cart)) {
                header('Location: cart.php'); 
            } else {
                if ($loginResult['User_Name'] === 'admin') {
                    header('Location: admin.php'); 
                } else {
                    header('Location: index.php'); 
                }
            }
            exit();
        } else {
            $errors[] = 'Login failed.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/style.css">
</head>

<body>
    <?php include('header.php'); ?>

    <div class="container-fluid">
        <div class="row login-container">
            <div class="col-md-6 login-image text-center">
                <img src="./images/draw2.png" alt="Login Image" style="max-width: 70%;">
            </div>
            <div class="col-md-6 login-form" style="max-width: 400px;">
                <div class="container">
                    <h2 class="text-center">User Login</h2>
                    <?php if (!empty($errors)) : ?>
                        <div class="alert alert-danger">
                            <?php foreach ($errors as $error) : ?>
                                <p><?php echo $error; ?></p>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    <form method="post" class="needs-validation" novalidate>
                        <div class="form-group">
                            <label for="username">Username:</label>
                            <input type="text" id="username" name="username" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Password:</label>
                            <input type="password" id="password" name="password" class="form-control" required>
                        </div>
                        <div class="form-group text-center">
                            <button type="submit" class="btn btn-primary text-center">Login</button>
                        </div>
                    </form>
                    <div class="text-center">
                        <a href="registration.php">Register Now</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</body>

</html>