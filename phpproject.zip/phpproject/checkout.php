<?php
session_start();
include_once './session/CustomSessionHandler.php';

$user = CustomSessionHandler::getUserDetails();
if (!$user) {
    header('Location: login.php');
}

// Get products from the session cart, if empty redirect to home Page...
$cart = CustomSessionHandler::getProductsInCart();
if (empty($cart)) {
    header('Location: index.php'); // Redirect to the cart page
}

// Check if user details are available in the session
$userDetails = CustomSessionHandler::getUserDetails();
// Prefill user details
$prefilledName = $userDetails['username'] ?? '';
$prefilledEmail = $userDetails['email'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout Page</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>

<body>
    <?php include('header.php'); ?>

    <div class="container mt-5">
        <h2 class="mb-4">Shipping Details</h2>
        <form action="process_checkout.php" method="post">

            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" value="<?= htmlspecialchars($prefilledName) ?>" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?= htmlspecialchars($prefilledEmail) ?>" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="address">Address:</label>
                <textarea id="address" name="address" rows="4" class="form-control" required></textarea>
            </div>

            <div class="form-group">
                <label for="payment_method">Payment Method:</label><br>
                <input type="radio" id="credit_card" name="payment_method" value="credit_card" required>
                <label for="credit_card">Credit Card</label><br>
                <input type="radio" id="paypal" name="payment_method" value="paypal" required>
                <label for="paypal">PayPal</label><br>
                <input type="radio" id="bank_transfer" name="payment_method" value="bank_transfer" required>
                <label for="bank_transfer">Bank Transfer</label><br>
                <!-- Add more payment methods if needed -->
            </div>


            <button type="submit" class="btn btn-primary">Place Order</button>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>

</html>