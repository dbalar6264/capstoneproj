<?php

class CustomSessionHandler
{
    public static function getProductsInCart()
    {
        return isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
    }

    public static function removeProductFromCart($productID)
    {
        if (isset($_SESSION['cart'][$productID])) {
            unset($_SESSION['cart'][$productID]);
        }
    }

    public static function isProductInCart($productID)
    {
        return isset($_SESSION['cart'][$productID]);
    }

    public static function getProductCountInCart($productID)
    {
        return isset($_SESSION['cart'][$productID]['quantity']) ? $_SESSION['cart'][$productID]['quantity'] : 0;
    }

    public static function updateProductCountInCart($productID, $productName, $quantity)
    {
        $quantity = intval($quantity);
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        if (isset($_SESSION['cart'][$productID])) {
            $_SESSION['cart'][$productID]['quantity'] += $quantity;
            if ($_SESSION['cart'][$productID]['quantity'] <= 0) {
                self::removeProductFromCart($productID);
            }
        } else {
            $_SESSION['cart'][$productID] = [
                'name' => $productName,
                'quantity' => $quantity,
            ];
        }

        return $_SESSION['cart'][$productID]['quantity'] ?? 0;
    }

    public static function clearCart()
    {
        if (isset($_SESSION['cart'])) {
            unset($_SESSION['cart']);
        }
    }

    public static function setUserDetails($userDetails)
    {
        $_SESSION['userDetails'] = $userDetails;
    }

    public static function getUserDetails()
    {
        return $_SESSION['userDetails'] ?? null;
    }

    public static function saveUserDetails($userId, $username, $email)
    {
        self::setUserDetails([
            'userId' => $userId,
            'username' => $username,
            'email' => $email,
        ]);
    }

    public static function increaseProductQuantity($productID) {
        if(isset($_SESSION['cart'][$productID])) {
            $_SESSION['cart'][$productID]['quantity']++;
        }
    }

    public static function decreaseProductQuantity($productID) {
        if(isset($_SESSION['cart'][$productID])) {
            $_SESSION['cart'][$productID]['quantity']--;
            if($_SESSION['cart'][$productID]['quantity'] <= 0) {
                unset($_SESSION['cart'][$productID]);
            }
        }
    }
}
