<?php
session_start();

require('fpdf/fpdf.php');
include_once './session/CustomSessionHandler.php';
include_once './database/ProductsDatabse.php';
include_once './database/UsersDatabase.php';


$user = CustomSessionHandler::getUserDetails();
if (!$user) {
    header('Location: login.php');
}

// Get OrderId from the URL
$orderId = $_GET['orderID'] ?? null;


$productsDB = new ProductsDatabse();
$usersDB = new UsersDatabase();

ob_start();
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 14);

$pdf->Cell(40, 10, 'Invoice Details', 0, 1, 'C');
$pdf->Ln();

// Fetch data from Orders based on $orderId
$orderDetails = $productsDB->getOrderDetails($orderId);
$userDetails = $usersDB->getUserDetails($orderDetails['User_ID']);


$pdf->Cell(50, 10, 'OrderId', 1);
$pdf->Cell(50, 10, 'Date', 1);
$pdf->Ln();


$pdf->Cell(50, 10, $orderDetails['Order_ID'], 1);
$pdf->Cell(50, 10, $orderDetails['Order_Date'], 1);
$pdf->Ln();
$pdf->Ln();


$pdf->Cell(50, 10, 'Customer Name', 1);
$pdf->Cell(50, 10, 'Customer Email', 1);
$pdf->Ln();



$pdf->Cell(50, 10, $userDetails['User_Name'], 1);
$pdf->Cell(50, 10, $userDetails['User_Email'], 1);
$pdf->Ln();
$pdf->Ln();


// table headers for order items
$pdf->Cell(40, 10, 'Product Name', 1);
$pdf->Cell(40, 10, 'Quantity', 1);
$pdf->Cell(40, 10, 'Price', 1);
$pdf->Cell(40, 10, 'Total', 1);
$pdf->Ln();


// Fetching data from OrderItems based on $orderId
$orderItems = $productsDB->getOrderItems($orderId);
$totalPrice = 0;

foreach ($orderItems as $itemRow) {
    $product = $productsDB->getProductDetails($itemRow['Product_ID']);
    $pdf->Cell(40, 10, $product->productName, 1);
    $pdf->Cell(40, 10, $itemRow['Quantity'], 1);
    $pdf->Cell(40, 10, $product->price, 1);
    $pdf->Cell(40, 10, $itemRow['Quantity'] * $product->price, 1);
    $pdf->Ln();
    $totalPrice = $totalPrice + $itemRow['Quantity'] * $product->price;
}

$pdf->Cell(120, 10, 'Total Cost:', 1);
$pdf->Cell(40, 10, $totalPrice, 1);

$pdf->Output('D');

ob_end_flush(); // Flush the output buffer
