<?php
include_once 'product.php';

class DatabaseHandler
{
    private $db;

    public function __construct($db)
    {
        $this->db = $db;
    }

    public function getCategories()
    {
        $sqlCategories = "SELECT Category_ID, Category_Name FROM Category";
        $resultCategories = $this->db->query($sqlCategories);

        $categories = [];
        while ($rowCategory = $resultCategories->fetch_assoc()) {
            $categories[] = $rowCategory;
        }

        return $categories;
    }

    public function getProducts($categoryID = null)
    {
        $sql = "SELECT * FROM Products";


        // Getting CategoryID from the URL queryparam and checking for its pattern
        if ($categoryID !== null && preg_match("/^[0-9]+$/", $categoryID) && $categoryID != 'all') {
            $sql .= " WHERE Category_ID = ?";
        }

        // Create a prepared statement and bind parameters
        $stmt = mysqli_prepare($this->db, $sql);
        if ($categoryID !== null && $categoryID != 'all') {
            mysqli_stmt_bind_param($stmt, "i", $categoryID);
        }

        $result = mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        $products = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $products[] = new Product(
                $row['Product_ID'],
                $row['Product_Name'],
                $row['Product_Brand'],
                $row['Quantity_Available'],
                $row['Price'],
                $row['Product_Description'],
                $row['Category_ID']
            );
        }

        return $products;
    }

    public function getProductDetails($productID)
    {
        $sql = "SELECT * FROM Products WHERE Product_ID = ?";

        $stmt = mysqli_prepare($this->db, $sql);
        mysqli_stmt_bind_param($stmt, "i", $productID);

        $result = mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        $product = null;
        if ($row = mysqli_fetch_assoc($result)) {
            $product = new Product(
                $row['Product_ID'],
                $row['Product_Name'],
                $row['Product_Brand'],
                $row['Quantity_Available'],
                $row['Price'],
                $row['Product_Description'],
                $row['Category_ID']
            );
        }

        return $product;
    }

    public function insertUser($username, $password, $email)
    {
        // Check if the user already exists either name or email should match 
        $checkUserQuery = "SELECT * FROM Users WHERE User_Name = ? OR User_Email = ?";
        $checkUserStmt = mysqli_prepare($this->db, $checkUserQuery);
        mysqli_stmt_bind_param($checkUserStmt, "ss", $username, $email);
        mysqli_stmt_execute($checkUserStmt);
        $existingUserResult = mysqli_stmt_get_result($checkUserStmt);

        if ($existingUserResult->num_rows > 0) {
            return false; // User already exists
        }

        // Insert the new user
        $insertUserQuery = "INSERT INTO Users (User_Name, User_Password, User_Email) VALUES (?, ?, ?)";
        $insertUserStmt = mysqli_prepare($this->db, $insertUserQuery);
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        mysqli_stmt_bind_param($insertUserStmt, "sss", $username, $hashedPassword, $email);

        $success = mysqli_stmt_execute($insertUserStmt);

        if ($success) {
            $userID = mysqli_insert_id($this->db);
            return $userID;
        } else {
            return null;
        }
    }

    public function loginUser($username, $password)
    {
        // Check if the user exists
        $checkUserQuery = "SELECT * FROM Users WHERE User_Name = ?";
        $checkUserStmt = mysqli_prepare($this->db, $checkUserQuery);
        mysqli_stmt_bind_param($checkUserStmt, "s", $username);
        mysqli_stmt_execute($checkUserStmt);
        $existingUserResult = mysqli_stmt_get_result($checkUserStmt);

        if ($existingUserResult->num_rows === 0) {
            return null;
        }

        $userDetails = mysqli_fetch_assoc($existingUserResult);

        // Verify the password
        if (password_verify($password, $userDetails['User_Password'])) {
            return $userDetails; // Login successful
        } else {
            return null; // Incorrect password
        }
    }


    //Save Order details into Order table and after that save OrderItems based on returned OrderId
    public function saveOrderDetails($userID, $address)
    {
        $sql = "INSERT INTO Orders (User_ID, Shipping_Address) VALUES (?, ?)";
        $stmt = mysqli_prepare($this->db, $sql);
        mysqli_stmt_bind_param($stmt, "ss", $userID, $address);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        return mysqli_insert_id($this->db);
    }

    // Save individual items of an Order in the Databse...
    public function saveOrderItem($orderID, $productID, $quantity)
    {
        $sql = "INSERT INTO OrderItems (Order_ID, Product_ID, Quantity) VALUES (?, ?, ?)";
        $stmt = mysqli_prepare($this->db, $sql);
        mysqli_stmt_bind_param($stmt, "iii", $orderID, $productID, $quantity);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }

    // Get details of a specific order based on Order_ID
    public function getOrderDetails($orderID)
    {
        $orderID = intval($orderID);
        $sql = "SELECT * FROM Orders WHERE Order_ID = ?";
        $stmt = mysqli_prepare($this->db, $sql);
        mysqli_stmt_bind_param($stmt, "i", $orderID);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $order = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $order[] = $row;
        }
        mysqli_stmt_close($stmt);

        return $order[0];
    }

    // Get all OrderItems based on Order_ID
    public function getOrderItems($orderID)
    {
        $sql = "SELECT * FROM OrderItems WHERE Order_ID = ?";
        $stmt = mysqli_prepare($this->db, $sql);
        mysqli_stmt_bind_param($stmt, "i", $orderID);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        $orderItems = [];
        while ($row = mysqli_fetch_assoc($result)) {
            $orderItems[] = $row;
        }

        mysqli_stmt_close($stmt);

        return $orderItems;
    }

    // Method to Delte the Product based on ProductId
    public function deleteProduct($productID)
    {
        $sql = "DELETE FROM Products WHERE Product_ID = ?";
        $stmt = mysqli_prepare($this->db, $sql);
        mysqli_stmt_bind_param($stmt, "i", $productID);
        $success = mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        return $success;
    }

    // Getting the Product Details Based on ID
    public function getProductById($productId)
    {
        $sql = "SELECT * FROM Products WHERE Product_ID = ?";
        $stmt = mysqli_prepare($this->db, $sql);
        mysqli_stmt_bind_param($stmt, "i", $productId);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $productDetails = mysqli_fetch_assoc($result);
        mysqli_stmt_close($stmt);

        return $productDetails;
    }

    // Udating the prodict details based in productId using where cluse..
    public function updateProduct($productId, $productName, $productDescription, $categoryID, $price, $brand)
    {
        $sql = "UPDATE Products SET Product_Name = ?, Product_Description = ?, Category_ID = ?, Price = ?, Product_Brand = ? WHERE Product_ID = ?";
        $stmt = mysqli_prepare($this->db, $sql);
        mysqli_stmt_bind_param($stmt, "ssidsi", $productName, $productDescription, $categoryID, $price, $brand, $productId);
        $success = mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        return $success;
    }

    //Creates a new Product in the Database...
    public function createProduct($productName, $productDescription, $quantityAvailable, $price, $brand, $categoryID)
    {
        $sql = "INSERT INTO Products (Product_Name, Product_Description, Quantity_Available, Price, Product_Brand, Category_ID) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($this->db, $sql);
        mysqli_stmt_bind_param($stmt, "ssidsi", $productName, $productDescription, $quantityAvailable, $price, $brand, $categoryID);
        $success = mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        return $success;
    }
}
