<?php
session_start();
include_once './session/CustomSessionHandler.php';

$user = CustomSessionHandler::getUserDetails();
if (!$user) {
    header('Location: login.php');
}

// Check if orderID is available in the URL
$orderID = isset($_GET['orderID']) ? $_GET['orderID'] : null;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Success</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>

<body class="bg-light">
    <?php include('header.php'); ?>
    <div class="container mt-5">
        <div class="card text-center">
            <div class="card-body">
                <h2 class="card-title text-success">&#10004; Order Successful</h2>

                <?php if ($orderID) : ?>
                    <p class="card-text">Your order with Order ID <?php echo $orderID; ?> has been placed successfully.</p>
                    <p class="card-text">Download your invoice: <a href="./download_invoice.php?orderID=<?php echo $orderID; ?>">Download Invoice</a></p>
                <?php else : ?>
                    <p class="card-text text-danger">Unable to get order information.</p>
                <?php endif; ?>

            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>

</html>