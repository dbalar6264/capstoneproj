<?php
session_start();
include_once './database/ProductsDatabse.php';

$productsDB = new ProductsDatabse();
$categories = $productsDB->getCategories();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Function to validate non-empty fields
    function validateField($field)
    {
        return !empty($field) ? htmlspecialchars($field, ENT_QUOTES, 'UTF-8') : null;
    }

    // Validate and sanitize each field
    $productName = validateField($_POST['productName']);
    $productDescription = validateField($_POST['productDescription']);
    $productBrand = validateField($_POST['productBrand']);
    $quantityAvailable = (int) validateField($_POST['quantityAvailable']);
    $price = validateField($_POST['price']);
    $categoryID = validateField($_POST['categoryID']);
    $imageUrl = validateField($_POST['imageUrl']);

    // Check if any required field is empty
    if ($productName !== null && $productDescription !== null && $productBrand !== null && $quantityAvailable !== null && $price !== null && $categoryID !== null && $imageUrl !== null) {
        $success = $productsDB->createProduct($productName, $productDescription, $quantityAvailable, $price, $productBrand, $categoryID, $imageUrl);

        if ($success) {
            header('Location: admin.php');
            exit();
        } else {
            echo 'Error processing the form';
        }
    } else {
        echo 'Please fill in all required fields';
    }
}

$prefilledProductName = '';
$prefilledProductDescription = '';
$prefilledProductBrand = '';
$prefilledQuantityAvailable = '';
$prefilledPrice = '';
$prefilledImageUrl = '';
$prefilledCategoryID = '';
?>

<!DOCTYPE html> 
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Product</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/style.css">
</head>

<body>
    <?php include('admin_access.php'); ?>
    <?php include('header.php'); ?>

    <div class="create-product-container my-5">
        <h2>Add New Product</h2>

        <form action="createProduct.php" method="POST">

            <div class="form-group">
                <label for="productName">Product Name:</label>
                <input type="text" class="form-control" id="productName" name="productName" value="<?= htmlspecialchars($prefilledProductName) ?>" required>
            </div>

            <div class="form-group">
                <label for="productDescription">Product Description:</label>
                <textarea class="form-control" id="productDescription" name="productDescription" rows="4" required><?= htmlspecialchars($prefilledProductDescription) ?></textarea>
            </div>

            <div class="form-group">
                <label for="productBrand">Product Brand:</label>
                <input type="text" class="form-control" id="productBrand" name="productBrand" value="<?= htmlspecialchars($prefilledProductBrand) ?>" required>
            </div>

            <div class="form-group">
                <label for="quantityAvailable">Quantity Available:</label>
                <input type="number" class="form-control" id="quantityAvailable" name="quantityAvailable" value="<?= htmlspecialchars($prefilledQuantityAvailable) ?>" required>
            </div>

            <div class="form-group">
                <label for="price">Price:</label>
                <input type="text" class="form-control" id="price" name="price" value="<?= htmlspecialchars($prefilledPrice) ?>" required>
            </div>

            <div class="form-group">
                <label for="price">ImageUrl:</label>
                <input type="text" class="form-control" id="imageUrl" name="imageUrl" value="<?= htmlspecialchars($prefilledImageUrl) ?>" required>
            </div>

            <div class="form-group">
                <label for="categoryID">Category:</label>
                <select class="form-control" id="categoryID" name="categoryID" required>
                    <option value="" disabled>Select Category</option>
                    <?php foreach ($categories as $category) : ?>
                        <option value="<?= $category['Category_ID'] ?>" <?= ($prefilledCategoryID == $category['Category_ID']) ? 'selected' : '' ?>>
                            <?= $category['Category_Name'] ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group text-center mt-4">
                <button type="submit" class="btn btn-primary">Add Product</button>
            </div>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>

</html>