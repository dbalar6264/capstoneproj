<?php
session_start();
include_once './session/CustomSessionHandler.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productID = $_POST['productID'];
    $quantity = $_POST['quantity'];
    $name = $_POST['name'];

    // Update the product count in the session cart
    $newCount = CustomSessionHandler::updateProductCountInCart($productID, $name, $quantity);
    echo $newCount;
} else {
    http_response_code(405);
}
