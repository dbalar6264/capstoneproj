<?php
require_once('./database/DatabaseInitializer.php');

if (isset($_POST['init_database'])) {
    $initializer = new DatabaseInitializer();
    $initializer->initDatabase();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Initialization</title>
</head>

<body>
    <form method="post">
        <button type="submit" name="init_database">Initialize Database</button>
    </form>
</body>

</html>