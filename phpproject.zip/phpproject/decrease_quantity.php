<?php
session_start();
include_once 'session/CustomSessionHandler.php';

if(isset($_GET['id'])) {
    $productID = $_GET['id'];
    CustomSessionHandler::decreaseProductQuantity($productID);
}

// Redirect back to the cart page
header("Location: cart.php");
exit();
?>
