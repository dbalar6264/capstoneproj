<?php
include_once './session/CustomSessionHandler.php';

// Get user details from the session
$userDetails = CustomSessionHandler::getUserDetails();

// Check if the user is logged in and is an admin
if ($userDetails && $userDetails['username'] === 'admin') {
    // User is an admin, continue with admin functionality
} else {
    header('Location: admin.php');
    exit();
}
