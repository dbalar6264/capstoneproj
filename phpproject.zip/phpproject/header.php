<?php
include_once './session/CustomSessionHandler.php';


?>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">ShoeStore</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav mr-auto">
            <?php
            // Check if the user is logged in and is not an admin
            $userDetails = CustomSessionHandler::getUserDetails();
            if ($userDetails && $userDetails['username'] !== 'admin') {
                echo '<li class="nav-item">';
                echo '<a class="nav-link active" href="index.php">Home</a>';
                echo '</li>';
            }
            ?>
            <?php
            // Check if the user is logged in and is an admin
            if ($userDetails && $userDetails['username'] === 'admin') {
                echo ' <li class="nav-item"><a class="nav-link active" href="admin.php">Admin Console</a></li>';
            }
            ?>
            <?php
            // Check if the user is logged in and is not an admin
            if ($userDetails && $userDetails['username'] !== 'admin') {
                echo '<li class="nav-item">';
                echo '<a class="nav-link active" href="cart.php">Cart</a>';
                echo '</li>';
            }
            ?>
        </ul>
        <ul class="navbar-nav">
            <?php
            // Check if user details are available in the session
            if ($userDetails) {
                // If user details are available, show the user's name
                echo '<li class="nav-item active"><span class="navbar-text nav-link active">' . $userDetails['email'] . '</span></li>';
                echo '<li class="nav-item"><a class="nav-link active" href="logout.php">Logout</a></li>';
            } else {
                // If user details are not available, show Login/Register
                echo '<li class="nav-item"><a class="nav-link active" href="login.php">Login</a></li>';
                echo '<li class="nav-item"><a class="nav-link active" href="registration.php">Register</a></li>';
            }
            ?>
        </ul>
    </div>
</nav>