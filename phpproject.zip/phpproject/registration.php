<?php
session_start();
include_once './session/CustomSessionHandler.php';
include_once './database/UsersDatabase.php';

$user = CustomSessionHandler::getUserDetails();
if ($user) {
    header('Location: index.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Handle form submission and registration process
    $username = $_POST['username'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    $errors = [];

    if (empty($username) || !preg_match("/^[a-zA-Z]+$/", $username)) {
        $errors[] = 'Username should contain only alphabets.';
    }

    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email address.';
    }

    if (empty($password) || empty($confirmPassword)) {
        $errors[] = 'All fields are required.';
    }

    if ($password !== $confirmPassword) {
        $errors[] = 'Password and Confirm Password not matching.';
    }

    if (empty($errors)) {

        $usersDB = new UsersDatabase();

        // Perform registration logic
        $registrationResult = $usersDB->insertUser($username, $password, $email);

        if ($registrationResult) {
            // Registration successful, save user details in the session
            CustomSessionHandler::saveUserDetails($registrationResult, $username, $email);

            $cart = CustomSessionHandler::getProductsInCart();

            if (!empty($cart)) {
                header('Location: cart.php'); // Redirect to the cart page
            } else {
                header('Location: index.php'); // Redirect to the index page
            }
            exit();
        } else {
            $errors[] = 'Registration failed. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/style.css">
</head>

<body>
    <?php include('header.php'); ?>

    <div class="container-fluid">
        <div class="row registration-container">
            <div class="col-md-6 login-form" style="max-width: 400px;">
                <div class="container">
                    <h2 class="text-center">User Registration</h2>
                    <?php if (!empty($errors)) : ?>
                        <div class="alert alert-danger">
                            <?php foreach ($errors as $error) : ?>
                                <p><?php echo $error; ?></p>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                    <form method="post" class="needs-validation" novalidate>
                        <div class="form-group">
                            <label for="username">Username:</label>
                            <input type="text" id="username" name="username" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="email" id="email" name="email" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label for="password">Password:</label>
                            <input type="password" id="password" name="password" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label for="confirm_password">Confirm Password:</label>
                            <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
                        </div>

                        <div class="form-group text-center">
                            <button type="submit" class="btn btn-primary">Register</button>
                        </div>

                    </form>
                    <div class="text-center">
                        <a href="login.php">Have an account? Login</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 login-image text-center">
                <img src="./images/draw1.png" alt="Registration Image" style="max-width: 70%;">
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</body>

</html>