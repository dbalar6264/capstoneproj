    <?php
    session_start();

    include_once './database/ProductsDatabse.php';

    $productsDB = new ProductsDatabse();
    $categories = $productsDB->getCategories();
    $categoryID = isset($_GET['categoryID']) ? $_GET['categoryID'] : null;
    $products = $productsDB->getProducts($categoryID);
    ?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Product List</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="./css/style.css">
    </head>

    <body>
        <?php include('header.php'); ?>

        <div class="container mt-5">

        <form method="get" action="index.php">
            <div class="form-group">
                <label for="search">Search:</label>
                <input type="text" class="form-control" id="search" name="search" placeholder="Search products">
                <button type="submit" class="btn btn-primary mt-2">Search</button>
            </div>
        </form>

        <div class="card mb-4">
                <img src="promotion.jpg" class="card-img-top" alt="Promotional Image">
                <div class="card-body">
                    <h5 class="card-title">Special Offer</h5>
                    <p class="card-text">Check out our latest deals and discounts!</p>
                    <a href="index.php" class="btn btn-primary">Shop Now</a>
                </div>
            </div>

       

            <!-- Category Dropdown -->
            <form method="get" action="index.php">
                <div class="form-group">
                    <label for="category">Select Category:</label>
                    <select class="form-control" id="categoryID" name="categoryID" onchange="this.form.submit()">
                        <option value="all">All Categories</option>
                        <?php foreach ($categories as $category) : ?>
                            <option value="<?= $category['Category_ID'] ?>" <?= ($categoryID == $category['Category_ID']) ? 'selected' : '' ?>>
                                <?= $category['Category_Name'] ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </form>

            <!-- Products -->
            <div class="row">
                <?php foreach ($products as $product) : ?>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <?php
                            $imageFiles = glob('./images/*.{jpg,jpeg,png,gif,webp}', GLOB_BRACE);
                            $randomImage = $imageFiles[array_rand($imageFiles)];
                            ?>
                            <img src="<?= ($product->imageUrl !== null && $product->imageUrl !== '') ? $product->imageUrl : $randomImage ?>" class="card-img-top" alt="Product Image">
                            <div class="card-body">
                                <h5 class="card-title"><?= $product->productName ?></h5>
                                <p class="brand-text">Brand: <?= $product->productBrand ?></p>
                                <p class="price-text">Price: $<?= $product->price ?></p>

                                <div class="btn-group">
                                    <button class="btn btn-secondary btn-lg" onclick="updateCart('<?= $product->productID ?>', '<?= $product->productName ?>', -1)">-</button>
                                    <span class="btn btn-light btn-sm" id="productCount_<?= $product->productID ?>">
                                        <?= CustomSessionHandler::getProductCountInCart($product->productID) ?>
                                    </span>
                                    <button class="btn btn-secondary btn-lg" onclick="updateCart('<?= $product->productID ?>', '<?= $product->productName ?>', 1)">+</button>
                                </div>

                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="container mt-5">
    <!-- Embedded YouTube Video -->
    <div class="embed-responsive embed-responsive-16by9 mb-4">
    <iframe width="560" height="315" src="https://www.youtube.com/embed/lBpS4FXC51s?si=MMZg-eUDJ70lcmso&autoplay=1&loop=1" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
</div>


            <div class="newsletter-section mt-5 p-4" style="background-color: #f8f9fa; border: 1px solid #ced4da; border-radius: 5px;">
    <h2>Sign up for our newsletter</h2>
    <p>Enter your email address below to receive updates about our latest products and promotions.</p>
    <form action="#" method="post">
        <div class="form-group">
            <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email address" required>
        </div>
        <button type="submit" class="btn btn-primary">Sign Up</button>
    </form>
</div>

        </div>

        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
        <script>
            // Function to update cart count using Fetch API
            async function updateCart(productID, productName, quantity) {
                try {
                    const presentCount = document.getElementById('productCount_' + productID);
                    if (presentCount.innerText == 0 && quantity == -1) {
                        return false;
                    }

                    const response = await fetch('update_cart.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: `productID=${productID}&quantity=${quantity}&name=${encodeURIComponent(productName)}`
                    });

                    if (response.ok) {
                        const newCount = await response.text();
                        presentCount.innerText = newCount;
                    } else {
                        console.error('Error updating cart count:', response.statusText);
                    }
                } catch (error) {
                    console.error('Error updating cart count:', error.message);
                }
            }
        </script>
    </body>

    </html>