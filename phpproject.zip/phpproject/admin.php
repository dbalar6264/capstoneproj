<?php
session_start();
include_once 'database/ProductsDatabse.php';

$productsDB = new ProductsDatabse();
$products = $productsDB->getProducts('all');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>

<body>
    <?php include('admin_access.php'); ?>
    <?php include('header.php'); ?>

    <div class="container mt-5">
        <h2 class="text-center">Admin Panel</h2>

        <div class="text-right mb-3">
            <a href="createproduct.php" class="btn btn-success">Add New Product</a>
        </div>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th scope="col">Product ID</th>
                    <th scope="col">Product Name</th>
                    <th scope="col">Brand</th>
                    <th scope="col">Quantity Available</th>
                    <th scope="col">Price</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($products as $product) : ?>
                    <tr>
                        <td><?= $product->productID ?></td>
                        <td><?= $product->productName ?></td>
                        <td><?= $product->productBrand ?></td>
                        <td><?= $product->quantityAvailable ?></td>
                        <td><?= $product->price ?></td>
                        <td>
                            <a href="editProduct.php?productId=<?= $product->productID ?>" class="btn btn-primary btn-sm">Edit</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>

</html>